// src/components/DocumentUpload.tsx

import React, { useState } from 'react';
import { useESignature } from '../hooks/useESignature';

/**
 * Composant pour uploader un document
 */
export const DocumentUpload: React.FC = () => {
  const { uploadDocument, loading, error, document } = useESignature();
  const [file, setFile] = useState<File | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!file) return;

    try {
      const result = await uploadDocument(file, 'current-user');
      console.log('Document uploaded:', result);
      alert(`Document uploadé avec succès! ID: ${result.id}`);
    } catch (err) {
      console.error('Upload failed:', err);
    }
  };

  return (
    <div className="upload-container">
      <h2>Upload Document PDF</h2>
      
      <input
        type="file"
        accept=".pdf"
        onChange={handleFileChange}
        disabled={loading}
      />
      
      <button onClick={handleUpload} disabled={!file || loading}>
        {loading ? 'Uploading...' : 'Upload'}
      </button>

      {error && <div className="error">{error}</div>}
      
      {document && (
        <div className="success">
          <p>✓ Document uploadé: {document.name}</p>
          <p>ID: {document.id}</p>
          <p>Status: {document.status}</p>
        </div>
      )}
    </div>
  );
};

// ============================================================================

/**
 * Composant pour signer avec une image
 */
export const SimpleSignature: React.FC<{ documentId: number }> = ({ documentId }) => {
  const { signWithImage, loading, error, document } = useESignature();
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [signerName, setSignerName] = useState('');
  const [signerEmail, setSignerEmail] = useState('');

  const handleSign = async () => {
    if (!imageFile || !signerName || !signerEmail) {
      alert('Veuillez remplir tous les champs');
      return;
    }

    try {
      const result = await signWithImage(
        documentId,
        signerName,
        signerEmail,
        imageFile,
        {
          page: 0,
          x: 400,
          y: 50,
          width: 150,
          height: 50,
        }
      );
      alert('Document signé avec succès!');
      console.log('Signed document:', result);
    } catch (err) {
      console.error('Signing failed:', err);
    }
  };

  return (
    <div className="signature-container">
      <h2>Signature Simple</h2>

      <input
        type="text"
        placeholder="Votre nom"
        value={signerName}
        onChange={(e) => setSignerName(e.target.value)}
        disabled={loading}
      />

      <input
        type="email"
        placeholder="Votre email"
        value={signerEmail}
        onChange={(e) => setSignerEmail(e.target.value)}
        disabled={loading}
      />

      <input
        type="file"
        accept="image/*"
        onChange={(e) => e.target.files && setImageFile(e.target.files[0])}
        disabled={loading}
      />

      <button onClick={handleSign} disabled={loading}>
        {loading ? 'Signature en cours...' : 'Signer le document'}
      </button>

      {error && <div className="error">{error}</div>}
      
      {document && document.status === 'SIGNED' && (
        <div className="success">
          ✓ Document signé avec succès!
        </div>
      )}
    </div>
  );
};

// ============================================================================

/**
 * Composant pour signer avec un certificat
 */
export const AdvancedSignature: React.FC<{ documentId: number }> = ({ documentId }) => {
  const { signWithCertificate, loading, error, document } = useESignature();
  const [certFile, setCertFile] = useState<File | null>(null);
  const [password, setPassword] = useState('');
  const [signerName, setSignerName] = useState('');
  const [signerEmail, setSignerEmail] = useState('');

  const handleSign = async () => {
    if (!certFile || !password || !signerName || !signerEmail) {
      alert('Veuillez remplir tous les champs');
      return;
    }

    try {
      const result = await signWithCertificate(
        documentId,
        signerName,
        signerEmail,
        certFile,
        password,
        'ADVANCED',
        {
          page: 0,
          x: 100,
          y: 200,
          width: 200,
          height: 80,
        }
      );
      alert('Document signé avec certificat!');
      console.log('Signed document:', result);
    } catch (err) {
      console.error('Certificate signing failed:', err);
    }
  };

  return (
    <div className="signature-container">
      <h2>Signature Avancée (Certificat)</h2>

      <input
        type="text"
        placeholder="Votre nom"
        value={signerName}
        onChange={(e) => setSignerName(e.target.value)}
        disabled={loading}
      />

      <input
        type="email"
        placeholder="Votre email"
        value={signerEmail}
        onChange={(e) => setSignerEmail(e.target.value)}
        disabled={loading}
      />

      <input
        type="file"
        accept=".p12,.pfx"
        onChange={(e) => e.target.files && setCertFile(e.target.files[0])}
        disabled={loading}
      />

      <input
        type="password"
        placeholder="Mot de passe du certificat"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        disabled={loading}
      />

      <button onClick={handleSign} disabled={loading}>
        {loading ? 'Signature en cours...' : 'Signer avec certificat'}
      </button>

      {error && <div className="error">{error}</div>}
      
      {document && document.status === 'SIGNED' && (
        <div className="success">
          ✓ Document signé avec certificat!
        </div>
      )}
    </div>
  );
};

// ============================================================================

/**
 * Composant pour créer un workflow multi-signataires
 */
export const WorkflowCreator: React.FC<{ documentId: number }> = ({ documentId }) => {
  const { createWorkflow, loading, error, workflows } = useESignature();
  const [signers, setSigners] = useState([
    { name: '', email: '', signOrder: 1, requiredSignatureType: 'SIMPLE' as const },
  ]);

  const addSigner = () => {
    setSigners([
      ...signers,
      {
        name: '',
        email: '',
        signOrder: signers.length + 1,
        requiredSignatureType: 'SIMPLE' as const,
      },
    ]);
  };

  const updateSigner = (index: number, field: string, value: any) => {
    const updated = [...signers];
    (updated[index] as any)[field] = value;
    setSigners(updated);
  };

  const handleCreateWorkflow = async () => {
    try {
      const result = await createWorkflow({
        documentId,
        expirationDays: 7,
        signers,
      });
      alert(`Workflow créé avec ${result.length} signataires!`);
      console.log('Workflow created:', result);
    } catch (err) {
      console.error('Workflow creation failed:', err);
    }
  };

  return (
    <div className="workflow-container">
      <h2>Créer un Workflow</h2>

      {signers.map((signer, index) => (
        <div key={index} className="signer-form">
          <h3>Signataire {index + 1}</h3>
          
          <input
            type="text"
            placeholder="Nom"
            value={signer.name}
            onChange={(e) => updateSigner(index, 'name', e.target.value)}
            disabled={loading}
          />

          <input
            type="email"
            placeholder="Email"
            value={signer.email}
            onChange={(e) => updateSigner(index, 'email', e.target.value)}
            disabled={loading}
          />

          <select
            value={signer.requiredSignatureType}
            onChange={(e) => updateSigner(index, 'requiredSignatureType', e.target.value)}
            disabled={loading}
          >
            <option value="SIMPLE">Signature Simple</option>
            <option value="ADVANCED">Signature Avancée</option>
            <option value="QUALIFIED">Signature Qualifiée</option>
          </select>
        </div>
      ))}

      <button onClick={addSigner} disabled={loading}>
        + Ajouter un signataire
      </button>

      <button onClick={handleCreateWorkflow} disabled={loading || signers.length === 0}>
        {loading ? 'Création...' : 'Créer le workflow'}
      </button>

      {error && <div className="error">{error}</div>}
      
      {workflows.length > 0 && (
        <div className="success">
          ✓ Workflow créé avec {workflows.length} signataires
          <ul>
            {workflows.map((w) => (
              <li key={w.id}>
                {w.signerName} ({w.signerEmail}) - Ordre: {w.signOrder} - Status: {w.status}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

// ============================================================================

/**
 * Composant pour télécharger et vérifier un document
 */
export const DocumentViewer: React.FC<{ documentId: number }> = ({ documentId }) => {
  const { getDocument, downloadDocument, verifyDocument, loading, error, document, verification } =
    useESignature();

  const handleDownload = async () => {
    try {
      await downloadDocument(documentId);
    } catch (err) {
      console.error('Download failed:', err);
    }
  };

  const handleVerify = async () => {
    try {
      const result = await verifyDocument(documentId);
      console.log('Verification result:', result);
    } catch (err) {
      console.error('Verification failed:', err);
    }
  };

  const handleRefresh = async () => {
    try {
      await getDocument(documentId);
    } catch (err) {
      console.error('Refresh failed:', err);
    }
  };

  return (
    <div className="document-viewer">
      <h2>Document #{documentId}</h2>

      <button onClick={handleRefresh} disabled={loading}>
        Actualiser
      </button>

      <button onClick={handleDownload} disabled={loading}>
        Télécharger PDF signé
      </button>

      <button onClick={handleVerify} disabled={loading}>
        Vérifier signatures
      </button>

      {error && <div className="error">{error}</div>}

      {document && (
        <div className="document-info">
          <h3>Informations</h3>
          <p><strong>Nom:</strong> {document.name}</p>
          <p><strong>Status:</strong> {document.status}</p>
          <p><strong>Taille:</strong> {(document.fileSize / 1024).toFixed(2)} KB</p>
          <p><strong>Créé le:</strong> {new Date(document.createdAt).toLocaleString()}</p>
          {document.signedAt && (
            <p><strong>Signé le:</strong> {new Date(document.signedAt).toLocaleString()}</p>
          )}
          
          {document.signatures && document.signatures.length > 0 && (
            <div>
              <h4>Signatures ({document.signatures.length})</h4>
              <ul>
                {document.signatures.map((sig) => (
                  <li key={sig.id}>
                    {sig.signerName} ({sig.signatureType}) - {new Date(sig.signedAt).toLocaleString()}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {verification && (
        <div className={`verification ${verification.isValid ? 'valid' : 'invalid'}`}>
          <h3>Résultat de vérification</h3>
          <p><strong>Valide:</strong> {verification.isValid ? '✓ Oui' : '✗ Non'}</p>
          <p><strong>Message:</strong> {verification.message}</p>
          
          {verification.signatures.map((sig, idx) => (
            <div key={idx} className="signature-verification">
              <h4>{sig.signerName}</h4>
              <p>Valide: {sig.isValid ? '✓' : '✗'}</p>
              {sig.validationErrors.length > 0 && (
                <ul>
                  {sig.validationErrors.map((err, i) => (
                    <li key={i}>{err}</li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
