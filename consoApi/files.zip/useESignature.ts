// src/hooks/useESignature.ts

import { useState, useCallback } from 'react';
import {
  ESignatureClient,
  DocumentResponse,
  SignatureType,
  SignDocumentRequest,
  CreateWorkflowRequest,
  WorkflowResponse,
  VerificationResponse,
} from '../api/esignature-client';

/**
 * Hook personnalisé pour gérer les opérations de signature électronique
 */
export const useESignature = (apiClient?: ESignatureClient) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [document, setDocument] = useState<DocumentResponse | null>(null);
  const [workflows, setWorkflows] = useState<WorkflowResponse[]>([]);
  const [verification, setVerification] = useState<VerificationResponse | null>(null);

  const client = apiClient || new ESignatureClient();

  /**
   * Upload un document
   */
  const uploadDocument = useCallback(
    async (file: File, uploadedBy: string = 'user') => {
      setLoading(true);
      setError(null);
      try {
        const result = await client.uploadDocument(file, uploadedBy);
        setDocument(result);
        return result;
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to upload document';
        setError(message);
        throw err;
      } finally {
        setLoading(false);
      }
    },
    [client]
  );

  /**
   * Récupérer un document
   */
  const getDocument = useCallback(
    async (documentId: number) => {
      setLoading(true);
      setError(null);
      try {
        const result = await client.getDocument(documentId);
        setDocument(result);
        return result;
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to get document';
        setError(message);
        throw err;
      } finally {
        setLoading(false);
      }
    },
    [client]
  );

  /**
   * Signer avec une image
   */
  const signWithImage = useCallback(
    async (
      documentId: number,
      signerName: string,
      signerEmail: string,
      imageFile: File,
      position?: { page?: number; x?: number; y?: number; width?: number; height?: number }
    ) => {
      setLoading(true);
      setError(null);
      try {
        const imageBase64 = await client.imageToBase64(imageFile);
        const result = await client.signWithImage(
          documentId,
          signerName,
          signerEmail,
          imageBase64,
          position
        );
        setDocument(result);
        return result;
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to sign document';
        setError(message);
        throw err;
      } finally {
        setLoading(false);
      }
    },
    [client]
  );

  /**
   * Signer avec un certificat
   */
  const signWithCertificate = useCallback(
    async (
      documentId: number,
      signerName: string,
      signerEmail: string,
      certificateFile: File,
      password: string,
      signatureType: SignatureType.ADVANCED | SignatureType.QUALIFIED = SignatureType.ADVANCED,
      position?: { page?: number; x?: number; y?: number; width?: number; height?: number }
    ) => {
      setLoading(true);
      setError(null);
      try {
        const certBase64 = await client.certificateToBase64(certificateFile);
        const result = await client.signWithCertificate(
          documentId,
          signerName,
          signerEmail,
          certBase64,
          password,
          signatureType,
          position
        );
        setDocument(result);
        return result;
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to sign with certificate';
        setError(message);
        throw err;
      } finally {
        setLoading(false);
      }
    },
    [client]
  );

  /**
   * Signer un document (générique)
   */
  const signDocument = useCallback(
    async (request: SignDocumentRequest) => {
      setLoading(true);
      setError(null);
      try {
        const result = await client.signDocument(request);
        setDocument(result);
        return result;
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to sign document';
        setError(message);
        throw err;
      } finally {
        setLoading(false);
      }
    },
    [client]
  );

  /**
   * Télécharger le document signé
   */
  const downloadDocument = useCallback(
    async (documentId: number, filename?: string) => {
      setLoading(true);
      setError(null);
      try {
        await client.downloadAndSaveDocument(documentId, filename);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to download document';
        setError(message);
        throw err;
      } finally {
        setLoading(false);
      }
    },
    [client]
  );

  /**
   * Créer un workflow
   */
  const createWorkflow = useCallback(
    async (request: CreateWorkflowRequest) => {
      setLoading(true);
      setError(null);
      try {
        const result = await client.createWorkflow(request);
        setWorkflows(result);
        return result;
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to create workflow';
        setError(message);
        throw err;
      } finally {
        setLoading(false);
      }
    },
    [client]
  );

  /**
   * Récupérer le workflow
   */
  const getWorkflow = useCallback(
    async (documentId: number) => {
      setLoading(true);
      setError(null);
      try {
        const result = await client.getWorkflow(documentId);
        setWorkflows(result);
        return result;
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to get workflow';
        setError(message);
        throw err;
      } finally {
        setLoading(false);
      }
    },
    [client]
  );

  /**
   * Rejeter une signature
   */
  const rejectSignature = useCallback(
    async (token: string, reason: string) => {
      setLoading(true);
      setError(null);
      try {
        const result = await client.rejectSignature(token, reason);
        return result;
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to reject signature';
        setError(message);
        throw err;
      } finally {
        setLoading(false);
      }
    },
    [client]
  );

  /**
   * Vérifier les signatures
   */
  const verifyDocument = useCallback(
    async (documentId: number) => {
      setLoading(true);
      setError(null);
      try {
        const result = await client.verifyDocument(documentId);
        setVerification(result);
        return result;
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to verify document';
        setError(message);
        throw err;
      } finally {
        setLoading(false);
      }
    },
    [client]
  );

  return {
    // State
    loading,
    error,
    document,
    workflows,
    verification,

    // Actions
    uploadDocument,
    getDocument,
    signWithImage,
    signWithCertificate,
    signDocument,
    downloadDocument,
    createWorkflow,
    getWorkflow,
    rejectSignature,
    verifyDocument,

    // Utils
    setError,
  };
};

export default useESignature;
