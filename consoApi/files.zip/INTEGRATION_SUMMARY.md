# 📦 Intégration TypeScript/React - Récapitulatif

## 🎯 Fichiers fournis

### Client API TypeScript
- **esignature-client.ts** - Client API complet avec toutes les méthodes
- **useESignature.ts** - Hook React personnalisé
- **ReactComponents.tsx** - Composants React prêts à l'emploi
- **package.json** - Configuration npm

### Guides d'intégration
- **TYPESCRIPT_GUIDE.md** - Guide complet TypeScript/React
- **NEXTJS_GUIDE.md** - Intégration spécifique Next.js
- **QUICK_START.md** - Démarrage rapide backend
- **ARCHITECTURE.md** - Architecture et déploiement

### Backend
- **esignature-api.zip** - API Spring Boot complète

## 🚀 Installation rapide

### Option 1 : Copier les fichiers directement

```bash
# Copier dans votre projet
cp esignature-client.ts src/api/
cp useESignature.ts src/hooks/
cp ReactComponents.tsx src/components/
```

### Option 2 : Créer comme package npm local

```bash
# Créer un dossier dans votre projet
mkdir -p packages/esignature-client
cd packages/esignature-client

# Copier les fichiers
cp path/to/esignature-client.ts .
cp path/to/package.json .

# Dans votre package.json principal
"dependencies": {
  "esignature-client": "file:./packages/esignature-client"
}
```

## 💡 Utilisation de base

### 1. Vanilla TypeScript

```typescript
import { ESignatureClient } from './api/esignature-client';

const api = new ESignatureClient('http://localhost:8080/api/v1');

// Upload
const doc = await api.uploadDocument(pdfFile, 'user@example.com');

// Sign
const signed = await api.signWithImage(
  doc.id,
  'John Doe',
  'john@example.com',
  imageBase64
);

// Download
await api.downloadAndSaveDocument(doc.id);
```

### 2. React avec Hook

```tsx
import { useESignature } from './hooks/useESignature';

function MyComponent() {
  const { uploadDocument, signWithImage, loading, error } = useESignature();

  const handleUpload = async (file: File) => {
    await uploadDocument(file, 'user@example.com');
  };

  return (
    <div>
      {loading && <p>Loading...</p>}
      {error && <p>Error: {error}</p>}
    </div>
  );
}
```

### 3. Next.js avec Server Actions

```tsx
// lib/actions.ts
'use server';
import { ESignatureClient } from './esignature-client';

export async function uploadDocument(formData: FormData) {
  const api = new ESignatureClient(process.env.API_URL!);
  const file = formData.get('file') as File;
  return await api.uploadDocument(file, 'user');
}
```

## 📋 Checklist d'intégration

### Configuration initiale
- [ ] Copier `esignature-client.ts` dans votre projet
- [ ] Définir `NEXT_PUBLIC_API_URL` dans `.env.local`
- [ ] Vérifier que l'API backend est lancée
- [ ] Tester la connexion avec un simple GET

### Fonctionnalités de base
- [ ] Upload de documents
- [ ] Signature simple (image)
- [ ] Téléchargement de documents signés
- [ ] Affichage du statut

### Fonctionnalités avancées
- [ ] Signature avec certificat
- [ ] Workflow multi-signataires
- [ ] Vérification de signatures
- [ ] Gestion des erreurs

### Production
- [ ] Ajouter authentification (JWT)
- [ ] Configurer CORS correctement
- [ ] Gérer le cache des documents
- [ ] Ajouter les logs d'erreur
- [ ] Tests unitaires

## 🔧 Configuration

### Variables d'environnement

```bash
# .env.local (React/Next.js)
NEXT_PUBLIC_API_URL=http://localhost:8080/api/v1
NEXT_PUBLIC_MAX_FILE_SIZE=52428800  # 50MB

# .env (Backend Spring Boot)
SERVER_PORT=8080
SPRING_DATASOURCE_URL=jdbc:postgresql://localhost:5432/esignature
```

### CORS (si nécessaire)

Le backend est déjà configuré pour accepter toutes les origines en dev. En production :

```java
// SecurityConfig.java
configuration.setAllowedOrigins(List.of(
  "https://your-frontend-domain.com"
));
```

## 🎨 Personnalisation des composants

### Modifier les styles

```tsx
// Ajouter vos propres classes CSS
<DocumentUpload className="my-custom-class" />

// Ou utiliser styled-components
import styled from 'styled-components';

const StyledUpload = styled.div`
  .upload-container {
    background: #f5f5f5;
    padding: 20px;
  }
`;
```

### Ajouter des callbacks

```tsx
const { uploadDocument } = useESignature();

const handleUpload = async (file: File) => {
  const result = await uploadDocument(file, 'user');
  
  // Votre logique custom
  if (result) {
    console.log('Document uploaded:', result.id);
    // Rediriger, afficher notification, etc.
  }
};
```

## 🐛 Debugging

### Vérifier la connexion API

```typescript
// Test de connexion simple
async function testConnection() {
  try {
    const response = await fetch('http://localhost:8080/api/v1/actuator/health');
    const data = await response.json();
    console.log('API Status:', data);
  } catch (error) {
    console.error('API not reachable:', error);
  }
}
```

### Activer les logs détaillés

```typescript
// Dans esignature-client.ts, ajouter des logs
private async handleResponse<T>(response: Response): Promise<T> {
  console.log('API Response:', response.status, response.statusText);
  
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    console.error('API Error:', error);
    throw new Error(error.message || `Request failed: ${response.status}`);
  }
  
  const data = await response.json();
  console.log('API Data:', data);
  return data;
}
```

### Problèmes courants

| Problème | Solution |
|----------|----------|
| CORS errors | Vérifier SecurityConfig.java, redémarrer backend |
| 401 Unauthorized | Ajouter token avec `api.setToken()` |
| File too large | Augmenter `spring.servlet.multipart.max-file-size` |
| Base64 trop long | Vérifier taille image de signature |
| Network timeout | Augmenter timeout dans fetch options |

## 📚 Exemples d'utilisation avancés

### 1. Upload avec progress

```typescript
async function uploadWithProgress(file: File, onProgress: (percent: number) => void) {
  const xhr = new XMLHttpRequest();
  
  xhr.upload.addEventListener('progress', (e) => {
    if (e.lengthComputable) {
      const percent = (e.loaded / e.total) * 100;
      onProgress(percent);
    }
  });
  
  return new Promise((resolve, reject) => {
    xhr.addEventListener('load', () => resolve(JSON.parse(xhr.response)));
    xhr.addEventListener('error', reject);
    
    const formData = new FormData();
    formData.append('file', file);
    
    xhr.open('POST', 'http://localhost:8080/api/v1/documents/upload');
    xhr.send(formData);
  });
}
```

### 2. Retry automatique

```typescript
async function uploadWithRetry(file: File, maxRetries = 3) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await api.uploadDocument(file, 'user');
    } catch (error) {
      if (i === maxRetries - 1) throw error;
      await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1)));
    }
  }
}
```

### 3. Batch upload

```typescript
async function uploadMultiple(files: File[]) {
  const results = await Promise.allSettled(
    files.map(file => api.uploadDocument(file, 'user'))
  );
  
  const successful = results.filter(r => r.status === 'fulfilled');
  const failed = results.filter(r => r.status === 'rejected');
  
  return { successful, failed };
}
```

## 🔐 Sécurité

### Validation côté client

```typescript
function validateFile(file: File): string | null {
  if (file.size > 50 * 1024 * 1024) {
    return 'Fichier trop volumineux (max 50MB)';
  }
  
  if (file.type !== 'application/pdf') {
    return 'Seuls les fichiers PDF sont acceptés';
  }
  
  return null;
}
```

### Sanitization des données

```typescript
function sanitizeInput(input: string): string {
  return input
    .trim()
    .replace(/[<>]/g, '')
    .substring(0, 255);
}
```

## 📊 Monitoring

### Logger les appels API

```typescript
class LoggedESignatureClient extends ESignatureClient {
  async uploadDocument(file: File, uploadedBy: string) {
    console.time('upload');
    try {
      const result = await super.uploadDocument(file, uploadedBy);
      console.timeEnd('upload');
      return result;
    } catch (error) {
      console.timeEnd('upload');
      console.error('Upload failed:', error);
      throw error;
    }
  }
}
```

## 🎯 Prochaines étapes

1. **Intégrer dans votre application**
   - Copier les fichiers nécessaires
   - Adapter à votre architecture
   - Tester chaque fonctionnalité

2. **Personnaliser l'UI**
   - Adapter les composants à votre design system
   - Ajouter vos propres styles
   - Créer des variantes si besoin

3. **Ajouter des features**
   - Notifications (toast, snackbar)
   - Prévisualisation PDF
   - Glisser-déposer pour upload
   - Signature pad plus avancé

4. **Préparer la production**
   - Configurer l'authentification
   - Ajouter la gestion d'erreurs robuste
   - Implémenter le monitoring
   - Écrire les tests

## 📞 Support

Pour toute question :
- Consulter les guides détaillés (TYPESCRIPT_GUIDE.md, NEXTJS_GUIDE.md)
- Vérifier les exemples dans ReactComponents.tsx
- Tester avec la collection Postman fournie

---

**Bonne intégration ! 🚀**
