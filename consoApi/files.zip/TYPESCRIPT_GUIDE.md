# 🎯 Guide Complet - Intégration TypeScript/React

## 📦 Installation

```bash
# Pas de dépendances externes nécessaires !
# Le client utilise uniquement fetch() natif
```

## 🗂️ Structure des fichiers

```
src/
├── api/
│   └── esignature-client.ts      # Client API TypeScript
├── hooks/
│   └── useESignature.ts          # Hook React personnalisé
└── components/
    └── DocumentComponents.tsx    # Composants React exemple
```

## 🚀 Utilisation rapide

### 1️⃣ Utilisation du client TypeScript (Vanilla)

```typescript
import { ESignatureClient, SignatureType } from './api/esignature-client';

// Créer une instance
const api = new ESignatureClient('http://localhost:8080/api/v1');

// Optionnel : Ajouter un token d'authentification
api.setToken('votre-jwt-token');

// Upload un document
const file = document.getElementById('fileInput').files[0];
const doc = await api.uploadDocument(file, 'jean.dupont');
console.log('Document ID:', doc.id);

// Signer avec une image
const signatureImage = document.getElementById('signatureInput').files[0];
const imageBase64 = await api.imageToBase64(signatureImage);
const signedDoc = await api.signWithImage(
  doc.id,
  'Jean Dupont',
  'jean@example.com',
  imageBase64,
  { page: 0, x: 400, y: 50, width: 150, height: 50 }
);

// Télécharger le PDF signé
await api.downloadAndSaveDocument(doc.id, 'contrat_signe.pdf');

// Vérifier les signatures
const verification = await api.verifyDocument(doc.id);
console.log('Document valide:', verification.isValid);
```

### 2️⃣ Utilisation avec React Hook

```tsx
import React from 'react';
import { useESignature } from './hooks/useESignature';

function MyComponent() {
  const {
    uploadDocument,
    signWithImage,
    downloadDocument,
    loading,
    error,
    document
  } = useESignature();

  const handleUpload = async (file: File) => {
    try {
      const result = await uploadDocument(file, 'user@example.com');
      console.log('Uploaded:', result);
    } catch (err) {
      console.error('Error:', err);
    }
  };

  return (
    <div>
      {loading && <p>Chargement...</p>}
      {error && <p>Erreur: {error}</p>}
      {document && <p>Document: {document.name}</p>}
    </div>
  );
}
```

### 3️⃣ Utilisation avec les composants fournis

```tsx
import React from 'react';
import {
  DocumentUpload,
  SimpleSignature,
  AdvancedSignature,
  WorkflowCreator,
  DocumentViewer
} from './components/DocumentComponents';

function App() {
  const [documentId, setDocumentId] = React.useState<number | null>(null);

  return (
    <div>
      <h1>Signature Électronique</h1>
      
      {/* Upload */}
      <DocumentUpload />
      
      {/* Signature simple */}
      {documentId && <SimpleSignature documentId={documentId} />}
      
      {/* Signature avancée */}
      {documentId && <AdvancedSignature documentId={documentId} />}
      
      {/* Workflow */}
      {documentId && <WorkflowCreator documentId={documentId} />}
      
      {/* Visualisation */}
      {documentId && <DocumentViewer documentId={documentId} />}
    </div>
  );
}
```

## 📝 Exemples détaillés

### Exemple 1 : Upload et signature simple

```typescript
import { esignatureAPI } from './api/esignature-client';

async function uploadAndSign() {
  // 1. Upload
  const fileInput = document.getElementById('pdf') as HTMLInputElement;
  const pdfFile = fileInput.files![0];
  const doc = await esignatureAPI.uploadDocument(pdfFile, 'user@example.com');
  
  // 2. Préparer l'image de signature
  const sigInput = document.getElementById('signature') as HTMLInputElement;
  const signatureFile = sigInput.files![0];
  const signatureBase64 = await esignatureAPI.imageToBase64(signatureFile);
  
  // 3. Signer
  const signedDoc = await esignatureAPI.signDocument({
    documentId: doc.id,
    signerName: 'Jean Dupont',
    signerEmail: 'jean@example.com',
    signatureType: 'SIMPLE',
    signatureImageBase64: signatureBase64,
    pageNumber: 0,
    xPosition: 400,
    yPosition: 50,
    width: 150,
    height: 50
  });
  
  // 4. Télécharger
  await esignatureAPI.downloadAndSaveDocument(signedDoc.id);
}
```

### Exemple 2 : Signature avec certificat

```typescript
async function signWithCertificate() {
  const documentId = 123;
  
  // Charger le certificat .p12
  const certInput = document.getElementById('certificate') as HTMLInputElement;
  const certFile = certInput.files![0];
  const certBase64 = await esignatureAPI.certificateToBase64(certFile);
  
  // Signer
  const result = await esignatureAPI.signDocument({
    documentId,
    signerName: 'Marie Martin',
    signerEmail: 'marie@example.com',
    signatureType: 'ADVANCED',
    certificateBase64: certBase64,
    certificatePassword: 'password123',
    pageNumber: 0,
    xPosition: 100,
    yPosition: 200,
    width: 200,
    height: 80
  });
  
  console.log('Document signé:', result);
}
```

### Exemple 3 : Workflow multi-signataires

```typescript
async function createSigningWorkflow() {
  const documentId = 123;
  
  const workflow = await esignatureAPI.createWorkflow({
    documentId,
    expirationDays: 7,
    signers: [
      {
        name: 'Directeur Général',
        email: 'dg@company.com',
        signOrder: 1,
        requiredSignatureType: 'ADVANCED'
      },
      {
        name: 'Responsable RH',
        email: 'rh@company.com',
        signOrder: 2,
        requiredSignatureType: 'SIMPLE'
      },
      {
        name: 'Employé',
        email: 'employe@company.com',
        signOrder: 3,
        requiredSignatureType: 'SIMPLE'
      }
    ]
  });
  
  console.log('Workflow créé:', workflow);
  // Chaque signataire reçoit un email avec son token unique
}
```

### Exemple 4 : Vérification de signature

```typescript
async function verifySignatures() {
  const documentId = 123;
  
  const verification = await esignatureAPI.verifyDocument(documentId);
  
  console.log('Document valide:', verification.isValid);
  console.log('Message:', verification.message);
  
  verification.signatures.forEach(sig => {
    console.log(`${sig.signerName}:`, sig.isValid ? '✓ Valide' : '✗ Invalide');
    
    if (!sig.isValid) {
      console.log('Erreurs:', sig.validationErrors);
    }
  });
}
```

### Exemple 5 : Application complète avec React

```tsx
import React, { useState } from 'react';
import { useESignature } from './hooks/useESignature';
import { SignatureType } from './api/esignature-client';

const CompleteSignatureFlow: React.FC = () => {
  const [step, setStep] = useState(1);
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [signatureImage, setSignatureImage] = useState<File | null>(null);
  
  const {
    uploadDocument,
    signWithImage,
    downloadDocument,
    verifyDocument,
    loading,
    error,
    document,
    verification
  } = useESignature();

  // Étape 1 : Upload
  const handleUpload = async () => {
    if (!pdfFile) return;
    const result = await uploadDocument(pdfFile, 'current-user');
    if (result) setStep(2);
  };

  // Étape 2 : Signature
  const handleSign = async () => {
    if (!document || !signatureImage) return;
    
    const result = await signWithImage(
      document.id,
      'Jean Dupont',
      'jean@example.com',
      signatureImage,
      { page: 0, x: 400, y: 50, width: 150, height: 50 }
    );
    
    if (result) setStep(3);
  };

  // Étape 3 : Vérification et téléchargement
  const handleVerify = async () => {
    if (!document) return;
    await verifyDocument(document.id);
  };

  const handleDownload = async () => {
    if (!document) return;
    await downloadDocument(document.id);
  };

  return (
    <div className="signature-flow">
      <h1>Processus de Signature</h1>
      
      {/* Progress */}
      <div className="steps">
        <span className={step >= 1 ? 'active' : ''}>1. Upload</span>
        <span className={step >= 2 ? 'active' : ''}>2. Signature</span>
        <span className={step >= 3 ? 'active' : ''}>3. Vérification</span>
      </div>

      {error && <div className="error">{error}</div>}
      {loading && <div className="loading">Chargement...</div>}

      {/* Étape 1 */}
      {step === 1 && (
        <div className="step">
          <h2>1. Téléverser le document</h2>
          <input
            type="file"
            accept=".pdf"
            onChange={(e) => e.target.files && setPdfFile(e.target.files[0])}
          />
          <button onClick={handleUpload} disabled={!pdfFile || loading}>
            Continuer
          </button>
        </div>
      )}

      {/* Étape 2 */}
      {step === 2 && document && (
        <div className="step">
          <h2>2. Signer le document</h2>
          <p>Document: {document.name}</p>
          <input
            type="file"
            accept="image/*"
            onChange={(e) => e.target.files && setSignatureImage(e.target.files[0])}
          />
          <button onClick={handleSign} disabled={!signatureImage || loading}>
            Signer
          </button>
        </div>
      )}

      {/* Étape 3 */}
      {step === 3 && document && (
        <div className="step">
          <h2>3. Document signé</h2>
          <p>✓ Votre document a été signé avec succès!</p>
          
          <button onClick={handleVerify} disabled={loading}>
            Vérifier les signatures
          </button>
          
          <button onClick={handleDownload} disabled={loading}>
            Télécharger le PDF signé
          </button>

          {verification && (
            <div className={`verification ${verification.isValid ? 'valid' : 'invalid'}`}>
              <h3>Résultat de vérification</h3>
              <p><strong>{verification.message}</strong></p>
              <p>Document valide: {verification.isValid ? '✓ Oui' : '✗ Non'}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CompleteSignatureFlow;
```

## 🎨 Styles CSS de base

```css
/* styles.css */
.upload-container,
.signature-container,
.workflow-container,
.document-viewer {
  padding: 20px;
  margin: 20px 0;
  border: 1px solid #ddd;
  border-radius: 8px;
}

.error {
  color: #d32f2f;
  background: #ffebee;
  padding: 10px;
  border-radius: 4px;
  margin: 10px 0;
}

.success {
  color: #2e7d32;
  background: #e8f5e9;
  padding: 10px;
  border-radius: 4px;
  margin: 10px 0;
}

.loading {
  text-align: center;
  padding: 20px;
  color: #666;
}

.verification.valid {
  background: #e8f5e9;
  border: 2px solid #4caf50;
  padding: 15px;
  border-radius: 8px;
}

.verification.invalid {
  background: #ffebee;
  border: 2px solid #f44336;
  padding: 15px;
  border-radius: 8px;
}

button {
  background: #1976d2;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 4px;
  cursor: pointer;
  margin: 5px;
}

button:disabled {
  background: #ccc;
  cursor: not-allowed;
}

input[type="text"],
input[type="email"],
input[type="password"],
select {
  width: 100%;
  padding: 10px;
  margin: 5px 0;
  border: 1px solid #ddd;
  border-radius: 4px;
}
```

## 🔒 Configuration avec authentification

```typescript
// Avec JWT
import { ESignatureClient } from './api/esignature-client';

const api = new ESignatureClient('http://localhost:8080/api/v1');

// Login (endpoint à implémenter côté backend)
async function login(username: string, password: string) {
  const response = await fetch('http://localhost:8080/api/v1/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  const { token } = await response.json();
  
  // Stocker le token
  localStorage.setItem('token', token);
  api.setToken(token);
}

// Restaurer le token au démarrage
const savedToken = localStorage.getItem('token');
if (savedToken) {
  api.setToken(savedToken);
}
```

## 🌐 Configuration CORS (Backend)

Si vous avez des problèmes CORS, vérifiez la configuration Spring Boot :

```java
// SecurityConfig.java déjà configuré avec :
configuration.setAllowedOrigins(List.of("*"));
configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
```

## ⚡ Optimisations

### Mise en cache des documents

```typescript
const documentCache = new Map<number, DocumentResponse>();

async function getDocumentCached(id: number) {
  if (documentCache.has(id)) {
    return documentCache.get(id)!;
  }
  
  const doc = await api.getDocument(id);
  documentCache.set(id, doc);
  return doc;
}
```

### Gestion des erreurs globale

```typescript
// error-handler.ts
export function handleAPIError(error: unknown) {
  if (error instanceof Error) {
    if (error.message.includes('401')) {
      // Rediriger vers login
      window.location.href = '/login';
    } else if (error.message.includes('403')) {
      alert('Accès non autorisé');
    } else {
      alert(`Erreur: ${error.message}`);
    }
  }
}
```

## 📱 Support Mobile

Le client fonctionne aussi sur mobile avec React Native :

```typescript
// Remplacer fetch par axios si nécessaire
import axios from 'axios';

// Dans le client, remplacer fetch() par axios
const response = await axios.post(url, data, { headers });
```

---

**Voilà ! Vous avez tout pour intégrer l'API dans votre application TypeScript/React ! 🎉**
