# 🚀 Intégration Next.js - E-Signature API

## Configuration Next.js

### 1. Structure du projet

```
my-app/
├── app/
│   ├── api/
│   │   └── signature/
│   │       └── route.ts          # Route handler API
│   ├── documents/
│   │   ├── page.tsx               # Liste documents
│   │   └── [id]/
│   │       └── page.tsx           # Détail document
│   └── sign/
│       └── page.tsx               # Page de signature
├── lib/
│   ├── esignature-client.ts      # Client API
│   └── actions.ts                 # Server Actions
└── components/
    └── signature/
        ├── DocumentUploader.tsx
        └── SignatureForm.tsx
```

### 2. Configuration de l'environnement

```bash
# .env.local
NEXT_PUBLIC_API_URL=http://localhost:8080/api/v1
API_SECRET_KEY=your-secret-key
```

## 📁 Server Components (App Router)

### Page de liste de documents

```tsx
// app/documents/page.tsx
import { ESignatureClient } from '@/lib/esignature-client';

async function getDocuments() {
  const api = new ESignatureClient(process.env.NEXT_PUBLIC_API_URL);
  // Récupérer les documents depuis votre backend
  return [];
}

export default async function DocumentsPage() {
  const documents = await getDocuments();

  return (
    <div>
      <h1>Mes Documents</h1>
      <div className="documents-grid">
        {documents.map((doc) => (
          <DocumentCard key={doc.id} document={doc} />
        ))}
      </div>
    </div>
  );
}
```

### Page de détail d'un document

```tsx
// app/documents/[id]/page.tsx
import { ESignatureClient } from '@/lib/esignature-client';
import { notFound } from 'next/navigation';

async function getDocument(id: string) {
  const api = new ESignatureClient(process.env.NEXT_PUBLIC_API_URL);
  try {
    return await api.getDocument(parseInt(id));
  } catch {
    return null;
  }
}

export default async function DocumentPage({
  params,
}: {
  params: { id: string };
}) {
  const document = await getDocument(params.id);

  if (!document) {
    notFound();
  }

  return (
    <div>
      <h1>{document.name}</h1>
      <p>Status: {document.status}</p>
      <p>Créé le: {new Date(document.createdAt).toLocaleDateString()}</p>
      
      {document.signatures && (
        <div>
          <h2>Signatures</h2>
          <ul>
            {document.signatures.map((sig) => (
              <li key={sig.id}>
                {sig.signerName} - {sig.signatureType}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
```

## 🎯 Server Actions (Recommandé)

```tsx
// lib/actions.ts
'use server';

import { ESignatureClient } from './esignature-client';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';

const api = new ESignatureClient(process.env.NEXT_PUBLIC_API_URL!);

export async function uploadDocument(formData: FormData) {
  try {
    const file = formData.get('file') as File;
    const uploadedBy = formData.get('uploadedBy') as string;

    const document = await api.uploadDocument(file, uploadedBy);
    
    revalidatePath('/documents');
    return { success: true, documentId: document.id };
  } catch (error) {
    return { success: false, error: 'Upload failed' };
  }
}

export async function signDocument(
  documentId: number,
  signerName: string,
  signerEmail: string,
  signatureImageBase64: string
) {
  try {
    const result = await api.signWithImage(
      documentId,
      signerName,
      signerEmail,
      signatureImageBase64
    );
    
    revalidatePath(`/documents/${documentId}`);
    return { success: true, document: result };
  } catch (error) {
    return { success: false, error: 'Signing failed' };
  }
}

export async function createWorkflow(
  documentId: number,
  signers: Array<{
    name: string;
    email: string;
    signOrder: number;
    requiredSignatureType: string;
  }>
) {
  try {
    const workflow = await api.createWorkflow({
      documentId,
      expirationDays: 7,
      signers,
    });
    
    revalidatePath(`/documents/${documentId}`);
    return { success: true, workflow };
  } catch (error) {
    return { success: false, error: 'Workflow creation failed' };
  }
}

export async function downloadDocument(documentId: number) {
  try {
    const blob = await api.downloadSignedDocument(documentId);
    // Retourner l'URL ou le blob
    return { success: true, blob };
  } catch (error) {
    return { success: false, error: 'Download failed' };
  }
}
```

## 🎨 Client Components

### Composant d'upload avec Server Actions

```tsx
// components/signature/DocumentUploader.tsx
'use client';

import { useState } from 'react';
import { uploadDocument } from '@/lib/actions';
import { useRouter } from 'next/navigation';

export function DocumentUploader() {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  async function handleSubmit(formData: FormData) {
    setUploading(true);
    setError(null);

    const result = await uploadDocument(formData);

    if (result.success) {
      router.push(`/documents/${result.documentId}`);
    } else {
      setError(result.error || 'Upload failed');
    }

    setUploading(false);
  }

  return (
    <form action={handleSubmit}>
      <input
        type="file"
        name="file"
        accept=".pdf"
        required
        disabled={uploading}
      />
      <input
        type="text"
        name="uploadedBy"
        placeholder="Votre nom"
        required
        disabled={uploading}
      />
      <button type="submit" disabled={uploading}>
        {uploading ? 'Upload...' : 'Uploader'}
      </button>
      {error && <p className="error">{error}</p>}
    </form>
  );
}
```

### Formulaire de signature avec canvas

```tsx
// components/signature/SignatureForm.tsx
'use client';

import { useState, useRef, useEffect } from 'react';
import { signDocument } from '@/lib/actions';

interface Props {
  documentId: number;
}

export function SignatureForm({ documentId }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [signerName, setSignerName] = useState('');
  const [signerEmail, setSignerEmail] = useState('');
  const [signing, setSigning] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.strokeStyle = '#000';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
  }, []);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const canvas = canvasRef.current;
    if (!canvas) return;

    setSigning(true);

    // Convertir le canvas en base64
    const base64 = canvas.toDataURL('image/png').split(',')[1];

    const result = await signDocument(
      documentId,
      signerName,
      signerEmail,
      base64
    );

    if (result.success) {
      alert('Document signé avec succès!');
      window.location.reload();
    } else {
      alert('Erreur: ' + result.error);
    }

    setSigning(false);
  };

  return (
    <form onSubmit={handleSubmit} className="signature-form">
      <div>
        <input
          type="text"
          placeholder="Votre nom"
          value={signerName}
          onChange={(e) => setSignerName(e.target.value)}
          required
        />
      </div>

      <div>
        <input
          type="email"
          placeholder="Votre email"
          value={signerEmail}
          onChange={(e) => setSignerEmail(e.target.value)}
          required
        />
      </div>

      <div className="canvas-container">
        <p>Dessinez votre signature:</p>
        <canvas
          ref={canvasRef}
          width={500}
          height={200}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          style={{ border: '1px solid #ccc', cursor: 'crosshair' }}
        />
        <button type="button" onClick={clearCanvas}>
          Effacer
        </button>
      </div>

      <button type="submit" disabled={signing}>
        {signing ? 'Signature...' : 'Signer le document'}
      </button>
    </form>
  );
}
```

## 🔀 Route Handlers (API Routes)

```tsx
// app/api/signature/upload/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { ESignatureClient } from '@/lib/esignature-client';

const api = new ESignatureClient(process.env.NEXT_PUBLIC_API_URL!);

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const uploadedBy = formData.get('uploadedBy') as string;

    const document = await api.uploadDocument(file, uploadedBy);

    return NextResponse.json({ success: true, document });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Upload failed' },
      { status: 500 }
    );
  }
}
```

```tsx
// app/api/signature/sign/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { ESignatureClient } from '@/lib/esignature-client';

const api = new ESignatureClient(process.env.NEXT_PUBLIC_API_URL!);

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    const document = await api.signDocument(body);

    return NextResponse.json({ success: true, document });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Signing failed' },
      { status: 500 }
    );
  }
}
```

## 📥 Téléchargement de fichiers

```tsx
// app/documents/[id]/download/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { ESignatureClient } from '@/lib/esignature-client';

const api = new ESignatureClient(process.env.NEXT_PUBLIC_API_URL!);

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const documentId = parseInt(params.id);
    const blob = await api.downloadSignedDocument(documentId);

    return new NextResponse(blob, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="document_${documentId}.pdf"`,
      },
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Download failed' },
      { status: 500 }
    );
  }
}
```

## 🎯 Hook personnalisé pour Next.js

```tsx
// hooks/useESignatureNext.ts
'use client';

import { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import * as actions from '@/lib/actions';

export function useESignatureNext() {
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  const uploadDocument = async (formData: FormData) => {
    setError(null);
    startTransition(async () => {
      const result = await actions.uploadDocument(formData);
      if (!result.success) {
        setError(result.error || 'Upload failed');
      }
    });
  };

  const signDocument = async (
    documentId: number,
    name: string,
    email: string,
    imageBase64: string
  ) => {
    setError(null);
    startTransition(async () => {
      const result = await actions.signDocument(documentId, name, email, imageBase64);
      if (!result.success) {
        setError(result.error || 'Signing failed');
      }
    });
  };

  return {
    isPending,
    error,
    uploadDocument,
    signDocument,
    setError,
  };
}
```

## 🔐 Middleware pour authentification

```tsx
// middleware.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  const token = request.cookies.get('auth_token')?.value;

  // Protéger les routes /documents
  if (request.nextUrl.pathname.startsWith('/documents')) {
    if (!token) {
      return NextResponse.redirect(new URL('/login', request.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/documents/:path*', '/sign/:path*'],
};
```

## 🎨 Exemple complet - Page de signature

```tsx
// app/sign/[id]/page.tsx
import { ESignatureClient } from '@/lib/esignature-client';
import { SignatureForm } from '@/components/signature/SignatureForm';
import { notFound } from 'next/navigation';

async function getDocument(id: string) {
  const api = new ESignatureClient(process.env.NEXT_PUBLIC_API_URL);
  try {
    return await api.getDocument(parseInt(id));
  } catch {
    return null;
  }
}

export default async function SignPage({
  params,
}: {
  params: { id: string };
}) {
  const document = await getDocument(params.id);

  if (!document) {
    notFound();
  }

  if (document.status === 'SIGNED') {
    return (
      <div>
        <h1>Document déjà signé</h1>
        <p>Ce document a déjà été signé.</p>
      </div>
    );
  }

  return (
    <div className="container">
      <h1>Signer le document</h1>
      <div className="document-info">
        <h2>{document.name}</h2>
        <p>Taille: {(document.fileSize / 1024).toFixed(2)} KB</p>
      </div>
      
      <SignatureForm documentId={document.id} />
    </div>
  );
}
```

---

**Votre API E-Signature est maintenant parfaitement intégrée avec Next.js ! 🎉**
