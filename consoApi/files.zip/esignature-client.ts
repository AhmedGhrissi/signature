// src/api/esignature-client.ts

/**
 * Client TypeScript pour l'API de Signature Électronique
 * Base URL: http://localhost:8080/api/v1
 */

// ============================================================================
// TYPES & INTERFACES
// ============================================================================

export enum SignatureType {
  SIMPLE = 'SIMPLE',
  ADVANCED = 'ADVANCED',
  QUALIFIED = 'QUALIFIED'
}

export enum SignatureStatus {
  PENDING = 'PENDING',
  SIGNED = 'SIGNED',
  REJECTED = 'REJECTED',
  EXPIRED = 'EXPIRED',
  CANCELLED = 'CANCELLED'
}

export interface DocumentResponse {
  id: number;
  name: string;
  mimeType: string;
  fileSize: number;
  uploadedBy: string;
  status: SignatureStatus;
  createdAt: string;
  signedAt?: string;
  expiresAt?: string;
  signatures?: SignatureResponse[];
  workflows?: WorkflowResponse[];
  downloadUrl?: string;
}

export interface SignatureResponse {
  id: number;
  signerName: string;
  signerEmail: string;
  signatureType: SignatureType;
  signedAt: string;
  certificateSerialNumber?: string;
  certificateIssuer?: string;
}

export interface WorkflowResponse {
  id: number;
  signerName: string;
  signerEmail: string;
  signOrder: number;
  requiredSignatureType: SignatureType;
  status: SignatureStatus;
  signedAt?: string;
  expiresAt?: string;
}

export interface SignDocumentRequest {
  documentId: number;
  signerName: string;
  signerEmail: string;
  signatureType: SignatureType;
  signatureImageBase64?: string;
  certificateBase64?: string;
  certificatePassword?: string;
  pageNumber?: number;
  xPosition?: number;
  yPosition?: number;
  width?: number;
  height?: number;
  signatureToken?: string;
}

export interface WorkflowSigner {
  name: string;
  email: string;
  signOrder: number;
  requiredSignatureType: SignatureType;
}

export interface CreateWorkflowRequest {
  documentId: number;
  expirationDays?: number;
  signers: WorkflowSigner[];
}

export interface VerificationResponse {
  isValid: boolean;
  message: string;
  signatures: SignatureVerification[];
}

export interface SignatureVerification {
  signerName: string;
  signerEmail: string;
  isValid: boolean;
  signedAt: string;
  certificateIssuer?: string;
  certificateSerialNumber?: string;
  certificateValidFrom?: string;
  certificateValidTo?: string;
  certificateValid?: boolean;
  validationErrors: string[];
}

// ============================================================================
// API CLIENT CLASS
// ============================================================================

export class ESignatureClient {
  private baseURL: string;
  private token?: string;

  constructor(baseURL: string = 'http://localhost:8080/api/v1', token?: string) {
    this.baseURL = baseURL;
    this.token = token;
  }

  /**
   * Set authentication token
   */
  setToken(token: string) {
    this.token = token;
  }

  /**
   * Get headers for requests
   */
  private getHeaders(includeContentType = true): HeadersInit {
    const headers: HeadersInit = {};
    
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }
    
    if (includeContentType) {
      headers['Content-Type'] = 'application/json';
    }
    
    return headers;
  }

  /**
   * Handle API errors
   */
  private async handleResponse<T>(response: Response): Promise<T> {
    if (!response.ok) {
      const error = await response.json().catch(() => ({
        message: `HTTP Error: ${response.status}`
      }));
      throw new Error(error.message || `Request failed with status ${response.status}`);
    }
    return response.json();
  }

  // ============================================================================
  // DOCUMENT METHODS
  // ============================================================================

  /**
   * Upload un document PDF
   * @param file - Fichier PDF à uploader
   * @param uploadedBy - Nom de l'utilisateur qui upload
   */
  async uploadDocument(file: File, uploadedBy: string = 'user'): Promise<DocumentResponse> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('uploadedBy', uploadedBy);

    const response = await fetch(`${this.baseURL}/documents/upload`, {
      method: 'POST',
      headers: this.token ? { 'Authorization': `Bearer ${this.token}` } : {},
      body: formData,
    });

    return this.handleResponse<DocumentResponse>(response);
  }

  /**
   * Récupérer les informations d'un document
   */
  async getDocument(documentId: number): Promise<DocumentResponse> {
    const response = await fetch(`${this.baseURL}/documents/${documentId}`, {
      method: 'GET',
      headers: this.getHeaders(),
    });

    return this.handleResponse<DocumentResponse>(response);
  }

  /**
   * Télécharger le document signé
   */
  async downloadSignedDocument(documentId: number): Promise<Blob> {
    const response = await fetch(`${this.baseURL}/documents/${documentId}/download`, {
      method: 'GET',
      headers: this.token ? { 'Authorization': `Bearer ${this.token}` } : {},
    });

    if (!response.ok) {
      throw new Error(`Failed to download document: ${response.status}`);
    }

    return response.blob();
  }

  /**
   * Télécharger et sauvegarder le document signé
   */
  async downloadAndSaveDocument(documentId: number, filename?: string): Promise<void> {
    const blob = await this.downloadSignedDocument(documentId);
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename || `signed_document_${documentId}.pdf`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }

  // ============================================================================
  // SIGNATURE METHODS
  // ============================================================================

  /**
   * Signer un document
   */
  async signDocument(request: SignDocumentRequest): Promise<DocumentResponse> {
    const response = await fetch(`${this.baseURL}/documents/sign`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(request),
    });

    return this.handleResponse<DocumentResponse>(response);
  }

  /**
   * Signer avec une signature simple (image)
   */
  async signWithImage(
    documentId: number,
    signerName: string,
    signerEmail: string,
    signatureImageBase64: string,
    position?: { page?: number; x?: number; y?: number; width?: number; height?: number }
  ): Promise<DocumentResponse> {
    return this.signDocument({
      documentId,
      signerName,
      signerEmail,
      signatureType: SignatureType.SIMPLE,
      signatureImageBase64,
      ...position,
    });
  }

  /**
   * Signer avec un certificat numérique
   */
  async signWithCertificate(
    documentId: number,
    signerName: string,
    signerEmail: string,
    certificateBase64: string,
    certificatePassword: string,
    signatureType: SignatureType.ADVANCED | SignatureType.QUALIFIED = SignatureType.ADVANCED,
    position?: { page?: number; x?: number; y?: number; width?: number; height?: number }
  ): Promise<DocumentResponse> {
    return this.signDocument({
      documentId,
      signerName,
      signerEmail,
      signatureType,
      certificateBase64,
      certificatePassword,
      ...position,
    });
  }

  /**
   * Convertir une image en base64
   */
  async imageToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = (reader.result as string).split(',')[1];
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  /**
   * Convertir un certificat en base64
   */
  async certificateToBase64(file: File): Promise<string> {
    return this.imageToBase64(file);
  }

  // ============================================================================
  // WORKFLOW METHODS
  // ============================================================================

  /**
   * Créer un workflow de signature multi-signataires
   */
  async createWorkflow(request: CreateWorkflowRequest): Promise<WorkflowResponse[]> {
    const response = await fetch(`${this.baseURL}/documents/workflow`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(request),
    });

    return this.handleResponse<WorkflowResponse[]>(response);
  }

  /**
   * Récupérer le workflow d'un document
   */
  async getWorkflow(documentId: number): Promise<WorkflowResponse[]> {
    const response = await fetch(`${this.baseURL}/documents/${documentId}/workflow`, {
      method: 'GET',
      headers: this.getHeaders(),
    });

    return this.handleResponse<WorkflowResponse[]>(response);
  }

  /**
   * Rejeter une signature dans un workflow
   */
  async rejectSignature(token: string, reason: string): Promise<WorkflowResponse> {
    const response = await fetch(
      `${this.baseURL}/documents/workflow/${token}/reject?reason=${encodeURIComponent(reason)}`,
      {
        method: 'POST',
        headers: this.getHeaders(),
      }
    );

    return this.handleResponse<WorkflowResponse>(response);
  }

  // ============================================================================
  // VERIFICATION METHODS
  // ============================================================================

  /**
   * Vérifier l'authenticité des signatures d'un document
   */
  async verifyDocument(documentId: number): Promise<VerificationResponse> {
    const response = await fetch(`${this.baseURL}/documents/${documentId}/verify`, {
      method: 'GET',
      headers: this.getHeaders(),
    });

    return this.handleResponse<VerificationResponse>(response);
  }
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

// Instance par défaut
export const esignatureAPI = new ESignatureClient();

export default ESignatureClient;
